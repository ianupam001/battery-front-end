import Preloader from '@/components/elements/Preloader'

export default function loading() {
    return (
        <>
            <Preloader />
        </>
    )
}
